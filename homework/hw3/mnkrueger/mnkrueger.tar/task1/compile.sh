#!/usr/bin/env bash
gcc -ggdb -O0 -o task1 task1.c
