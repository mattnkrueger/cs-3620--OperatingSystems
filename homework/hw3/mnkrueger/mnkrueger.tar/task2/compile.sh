#!/bin/bash
gcc -o task2 task2.c
